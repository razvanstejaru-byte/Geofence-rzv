package ro.razvan.geoalert;

import android.content.*;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (c.getSharedPreferences("cfg", 0).getBoolean("enabled", false)) {
            try {
                c.startForegroundService(new Intent(c, GeoService.class));
            } catch (Exception ignored) {}
        }
    }
}
