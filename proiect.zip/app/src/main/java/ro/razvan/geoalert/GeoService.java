package ro.razvan.geoalert;

import android.app.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.location.*;
import android.os.*;

public class GeoService extends Service implements LocationListener {
    LocationManager lm;
    SharedPreferences p;
    int streak = 0;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        p = getSharedPreferences("cfg", 0);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("svc", "Monitorizare", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "svc")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("GeoAlert activ")
                .setContentText("Monitorizez zona setată")
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(1, n);
        }
        if (lm == null) {
            lm = getSystemService(LocationManager.class);
            try {
                for (String s : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                    if (lm.getAllProviders().contains(s)) lm.requestLocationUpdates(s, 5000, 0, this);
                }
            } catch (SecurityException e) {
                stopSelf();
            }
        }
        return START_STICKY;
    }

    @Override
    public void onLocationChanged(Location l) {
        double la, lo, r;
        try {
            la = Double.parseDouble(p.getString("lat", ""));
            lo = Double.parseDouble(p.getString("lon", ""));
            r = Double.parseDouble(p.getString("rad", ""));
        } catch (Exception e) { return; }
        if (l.getAccuracy() > Math.max(50, r)) return;
        float[] d = new float[1];
        Location.distanceBetween(l.getLatitude(), l.getLongitude(), la, lo, d);
        int now = d[0] <= r ? 1 : 0;
        int st = p.getInt("inside", -1);
        if (st == -1) { p.edit().putInt("inside", now).apply(); return; }
        if (now == st) { streak = 0; return; }
        if (++streak < 2) return;
        streak = 0;
        p.edit().putInt("inside", now).apply();
        String app = p.getString("label", "aplicația");
        if (now == 1 && p.getBoolean("in", true)) Alerter.start(this, "Ai intrat în zonă. Deschide " + app);
        if (now == 0 && p.getBoolean("out", true)) Alerter.start(this, "Ai ieșit din zonă. Deschide " + app);
    }

    @Override
    public void onDestroy() {
        if (lm != null) lm.removeUpdates(this);
        super.onDestroy();
    }

    @Override public void onStatusChanged(String s, int st, Bundle b) {}
    @Override public void onProviderEnabled(String s) {}
    @Override public void onProviderDisabled(String s) {}
}
