package ro.razvan.geoalert;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    SharedPreferences p;
    EditText lat, lon, rad;
    Button appBtn;
    CheckBox cin, cout;
    TextView status;
    String pkg = "", label = "";

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    EditText field(LinearLayout l, String hint, String key) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setText(p.getString(key, ""));
        l.addView(e);
        return e;
    }

    Button btn(LinearLayout l, String t, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t);
        b.setOnClickListener(c);
        l.addView(b);
        return b;
    }

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        p = getSharedPreferences("cfg", 0);
        pkg = p.getString("pkg", "");
        label = p.getString("label", "");
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(24), dp(16), dp(24));
        sv.addView(l);
        status = new TextView(this);
        l.addView(status);
        lat = field(l, "Latitudine", "lat");
        lon = field(l, "Longitudine", "lon");
        rad = field(l, "Rază (metri)", "rad");
        btn(l, "Folosește locația mea curentă", v -> useHere());
        appBtn = btn(l, "", v -> pickApp());
        cin = new CheckBox(this);
        cin.setText("Alertă la intrare");
        cin.setChecked(p.getBoolean("in", true));
        l.addView(cin);
        cout = new CheckBox(this);
        cout.setText("Alertă la ieșire");
        cout.setChecked(p.getBoolean("out", true));
        l.addView(cout);
        btn(l, "1. Acordă permisiuni (locație + notificări)", v -> perms());
        btn(l, "2. Activează serviciul de accesibilitate", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        btn(l, "3. Fără optimizare baterie", v -> battery());
        btn(l, "Salvează și pornește", v -> start());
        btn(l, "Oprește", v -> stop());
        btn(l, "Test alertă", v -> { if (save()) Alerter.start(this, "Test alertă. Deschide " + label); });
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    void refresh() {
        appBtn.setText(label.isEmpty() ? "Alege aplicația țintă" : "Aplicație: " + label);
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean acc = en != null && en.contains(getPackageName());
        boolean bg = Build.VERSION.SDK_INT < 29 || checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED;
        status.setText("Serviciu: " + (p.getBoolean("enabled", false) ? "pornit" : "oprit")
                + "\nAccesibilitate: " + (acc ? "activă" : "INACTIVĂ")
                + "\nLocație în fundal: " + (bg ? "da" : "NU"));
    }

    boolean save() {
        try {
            double la = Double.parseDouble(lat.getText().toString().replace(',', '.'));
            double lo = Double.parseDouble(lon.getText().toString().replace(',', '.'));
            double r = Double.parseDouble(rad.getText().toString().replace(',', '.'));
            if (r <= 0 || pkg.isEmpty()) throw new Exception();
            p.edit().putString("lat", "" + la).putString("lon", "" + lo).putString("rad", "" + r)
                    .putString("pkg", pkg).putString("label", label)
                    .putBoolean("in", cin.isChecked()).putBoolean("out", cout.isChecked())
                    .putInt("inside", -1).apply();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "Completează locația, raza și aplicația", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    void start() {
        if (!save()) return;
        p.edit().putBoolean("enabled", true).apply();
        startForegroundService(new Intent(this, GeoService.class));
        refresh();
    }

    void stop() {
        p.edit().putBoolean("enabled", false).apply();
        stopService(new Intent(this, GeoService.class));
        Alerter.stop(this);
        refresh();
    }

    void useHere() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            perms();
            return;
        }
        LocationManager lm = getSystemService(LocationManager.class);
        Location best = null;
        for (String s : lm.getAllProviders()) {
            try {
                Location x = lm.getLastKnownLocation(s);
                if (x != null && (best == null || x.getTime() > best.getTime())) best = x;
            } catch (SecurityException ignored) {}
        }
        if (best == null) {
            Toast.makeText(this, "Nu am locație. Pornește GPS-ul și încearcă din nou.", Toast.LENGTH_LONG).show();
            return;
        }
        lat.setText("" + best.getLatitude());
        lon.setText("" + best.getLongitude());
        if (rad.getText().length() == 0) rad.setText("200");
    }

    void pickApp() {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        Collections.sort(list, (a, b) -> a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
        String[] names = new String[list.size()];
        for (int k = 0; k < names.length; k++) names[k] = list.get(k).loadLabel(pm).toString();
        new AlertDialog.Builder(this).setTitle("Alege aplicația").setItems(names, (d, w) -> {
            pkg = list.get(w).activityInfo.packageName;
            label = names[w];
            refresh();
        }).show();
    }

    void perms() {
        ArrayList<String> need = new ArrayList<>();
        need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        need.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(need.toArray(new String[0]), 1);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == 1 && Build.VERSION.SDK_INT >= 29
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Alege „Permite tot timpul” la locație", Toast.LENGTH_LONG).show();
            requestPermissions(new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION}, 2);
        }
        refresh();
    }

    void battery() {
        PowerManager pm = getSystemService(PowerManager.class);
        if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } else {
            Toast.makeText(this, "Deja setat", Toast.LENGTH_SHORT).show();
        }
    }
}
