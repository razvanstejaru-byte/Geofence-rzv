package ro.razvan.geoalert;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

public class WatchService extends AccessibilityService {
    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getPackageName() == null) return;
        String target = getSharedPreferences("cfg", 0).getString("pkg", "");
        if (!target.isEmpty() && e.getPackageName().toString().equals(target)) {
            Alerter.stop(this);
        }
    }

    @Override
    public void onInterrupt() {}
}
