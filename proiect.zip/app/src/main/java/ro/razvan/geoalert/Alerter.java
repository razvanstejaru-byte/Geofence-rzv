package ro.razvan.geoalert;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.*;

public class Alerter {
    static final String CH = "alert";
    static final Handler H = new Handler(Looper.getMainLooper());
    static boolean active = false;

    static void start(Context c, String msg) {
        final Context a = c.getApplicationContext();
        if (active) return;
        active = true;
        NotificationManager nm = a.getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CH, "Alerte", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 800, 300, 800});
        ch.setBypassDnd(true);
        nm.createNotificationChannel(ch);
        final String m = msg;
        H.post(new Runnable() {
            public void run() {
                if (!active) return;
                fire(a, m);
                H.postDelayed(this, 4000);
            }
        });
    }

    static void fire(Context a, String msg) {
        String pkg = a.getSharedPreferences("cfg", 0).getString("pkg", "");
        Intent li = a.getPackageManager().getLaunchIntentForPackage(pkg);
        Notification.Builder b = new Notification.Builder(a, CH)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("GeoAlert")
                .setContentText(msg)
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true);
        if (li != null) {
            b.setContentIntent(PendingIntent.getActivity(a, 0, li, PendingIntent.FLAG_IMMUTABLE));
        }
        a.getSystemService(NotificationManager.class).notify(2, b.build());
        Vibrator v = a.getSystemService(Vibrator.class);
        if (v != null) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 800, 300, 800}, -1));
    }

    static void stop(Context c) {
        if (!active) return;
        active = false;
        H.removeCallbacksAndMessages(null);
        c.getSystemService(NotificationManager.class).cancel(2);
    }
}
